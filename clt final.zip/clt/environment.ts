export const environment = {
  firebase: {
    apiKey: "AIzaSyBHpmhLLDBpNcMJH0lDbVMB9OGqsLhXASw",
    authDomain: "friendlychat1-7627b.firebaseapp.com",
    projectId: "friendlychat1-7627b",
    storageBucket: "friendlychat1-7627b.appspot.com",
    messagingSenderId: "881886645950",
    appId: "1:881886645950:web:c54c851642a936e45f98ef",
    measurementId: "G-7JC5V0JKPK"
  },
};
